﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Partial Class VB
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Dim script As String = "$(document).ready(function () { $('[id*=btnSubmit]').click(); });"
            ClientScript.RegisterStartupScript(Me.GetType, "load", script, True)
        End If
    End Sub

    Protected Sub Submit(ByVal sender As Object, ByVal e As EventArgs)
        ' Add Fake Delay to simulate long running process.
        System.Threading.Thread.Sleep(5000)
        Me.LoadCustomers()
    End Sub

    Private Sub LoadCustomers()
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Dim query As String = "SELECT CustomerId, ContactName, City FROM Customers WHERE Country = @Country OR @Country = ''"
        Using con As SqlConnection = New SqlConnection(constr)
            Using cmd As SqlCommand = New SqlCommand(query)
                cmd.Parameters.AddWithValue("@Country", ddlCountries.SelectedItem.Value)
                cmd.Connection = con
                Using sda As SqlDataAdapter = New SqlDataAdapter()
                    sda.SelectCommand = cmd
                    Using dt As DataTable = New DataTable()
                        sda.Fill(dt)
                        gvCustomers.DataSource = dt
                        gvCustomers.DataBind()
                    End Using
                End Using
            End Using
        End Using
    End Sub
End Class


