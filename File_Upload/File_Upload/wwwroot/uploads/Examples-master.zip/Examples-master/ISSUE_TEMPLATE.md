Try StackOverflow! If you have a _usage question_ ("How do I...?" "Others have this working but I can't get it...") please try [StackOverflow](https://stackoverflow.com) and tag your question `autofac`. We, along with a great community, monitor those questions.

**Have you [read the docs?](https://autofac.readthedocs.io/)**

**This repo is for Autofac example issues only.** If you found a bug in the examples or have an idea for a new example that would be helpful, you're in the right place. Everything else, please file it in the appropriate repo or ask questions on StackOverflow. Thanks!