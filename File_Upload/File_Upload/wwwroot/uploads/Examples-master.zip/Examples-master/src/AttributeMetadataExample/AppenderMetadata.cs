﻿using System;
using System.Linq;

namespace AttributeMetadataExample
{
    public class AppenderMetadata
    {
        public string AppenderName { get; set; }
    }
}
