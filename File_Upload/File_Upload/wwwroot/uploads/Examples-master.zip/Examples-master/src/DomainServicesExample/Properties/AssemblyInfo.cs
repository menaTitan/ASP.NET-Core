﻿using System.Reflection;

[assembly: AssemblyTitle("DomainServicesExample")]
