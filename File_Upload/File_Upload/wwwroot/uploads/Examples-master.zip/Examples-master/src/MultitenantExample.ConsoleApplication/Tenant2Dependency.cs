﻿using System;

namespace MultitenantExample.ConsoleApplication
{
    /// <summary>
    /// Tenant-specific dependency for Tenant 2.
    /// </summary>
    public class Tenant2Dependency : BaseDependency
    {
    }
}
