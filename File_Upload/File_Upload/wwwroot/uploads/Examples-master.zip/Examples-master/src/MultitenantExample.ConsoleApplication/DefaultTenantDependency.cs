﻿using System;

namespace MultitenantExample.ConsoleApplication
{
    /// <summary>
    /// Tenant-specific dependency for the default tenant.
    /// </summary>
    public class DefaultTenantDependency : BaseDependency
    {
    }
}
