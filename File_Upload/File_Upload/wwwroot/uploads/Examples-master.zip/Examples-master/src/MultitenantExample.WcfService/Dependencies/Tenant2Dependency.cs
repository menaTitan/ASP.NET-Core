﻿using System;

namespace MultitenantExample.WcfService.Dependencies
{
    /// <summary>
    /// Tenant-specific dependency for Tenant 2.
    /// </summary>
    public class Tenant2Dependency : BaseDependency
    {
    }
}
